# ClASSIC-4-PLAYERS-LUDO-GAME
Ludo is a traditional board game, typically of a square shaped board for two or four players in which the players race their four tokens from start to finish according to the rolls of a single die.

GAME RULES:
RULE 1 : Maximum No.of Players Allowed : 2-4 players
RULE 2 : Each player rolls a die; the highest roller begins the game.
RULE 3 : Players alternate turns in a clockwise direction. 
RULE 4 : To enter a token into play from its yard to its starting square, a player must roll a six. 
RULE 5 : Players can draw a token from home every time they get a six unless home is empty or move a piece six times.
RULE 7 : The Player who reaches the home space with all 4 of his pawns first is considered to be the winner of the game. 
 
 
